/*******************************************************************************
 * Copyright 2011 See AUTHORS file.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

package com.badlogic.gdx.maps.tiled;

import com.badlogic.gdx.assets.AssetDescriptor;
import com.badlogic.gdx.assets.loaders.FileHandleResolver;
import com.badlogic.gdx.assets.loaders.TextureLoader;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.ImageResolver;
import com.badlogic.gdx.maps.MapGroupLayer;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapLayers;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.maps.objects.EllipseMapObject;
import com.badlogic.gdx.maps.objects.PointMapObject;
import com.badlogic.gdx.maps.objects.PolygonMapObject;
import com.badlogic.gdx.maps.objects.PolylineMapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.objects.TextMapObject;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer.Cell;
import com.badlogic.gdx.maps.tiled.objects.TiledMapTileMapObject;
import com.badlogic.gdx.maps.tiled.tiles.AnimatedTiledMapTile;
import com.badlogic.gdx.maps.tiled.tiles.StaticTiledMapTile;
import com.badlogic.gdx.math.Polygon;
import com.badlogic.gdx.math.Polyline;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Base64Coder;
import com.badlogic.gdx.utils.GdxRuntimeException;
import com.badlogic.gdx.utils.IntArray;
import com.badlogic.gdx.utils.IntMap;
import com.badlogic.gdx.utils.ObjectMap;
import com.badlogic.gdx.utils.ObjectIntMap;
import com.badlogic.gdx.utils.ObjectSet;
import com.badlogic.gdx.utils.SerializationException;
import com.badlogic.gdx.utils.StreamUtils;
import com.badlogic.gdx.utils.XmlReader;
import com.badlogic.gdx.utils.XmlReader.Element;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;

public abstract class BaseTmxMapLoader<P extends BaseTiledMapLoader.Parameters> extends BaseTiledMapLoader<P> {

	protected XmlReader xml = new XmlReader();
	protected Element root;

	protected ObjectMap<String, Element> templateCache;
	protected ObjectIntMap<String> tilesetPathsToGIDs;

	public BaseTmxMapLoader (FileHandleResolver resolver) {
		super(resolver);
	}

	@Override
	public Array<AssetDescriptor> getDependencies (String fileName, FileHandle tmxFile, P parameter) {
		this.root = xml.parse(tmxFile);

		TextureLoader.TextureParameter textureParameter = new TextureLoader.TextureParameter();
		if (parameter != null) {
			textureParameter.genMipMaps = parameter.generateMipMaps;
			textureParameter.minFilter = parameter.textureMinFilter;
			textureParameter.magFilter = parameter.textureMagFilter;
		}

		return getDependencyAssetDescriptors(tmxFile, textureParameter);
	}

	/** Loads the map data, given the XML root element
	 *
	 * @param tmxFile the Filehandle of the tmx file
	 * @param parameter
	 * @param imageResolver
	 * @return the {@link TiledMap} */
	@Override
	protected TiledMap loadTiledMap (FileHandle tmxFile, P parameter, ImageResolver imageResolver) {
		this.map = new TiledMap();
		this.idToObject = new IntMap<>();
		this.runOnEndOfLoadTiled = new Array<>();
		this.templateCache = new ObjectMap<>();
		this.tilesetPathsToGIDs = new ObjectIntMap<>();

		if (parameter != null) {
			this.convertObjectToTileSpace = parameter.convertObjectToTileSpace;
			this.flipY = parameter.flipY;
			loadProjectFile(parameter.projectFilePath);
		} else {
			this.convertObjectToTileSpace = false;
			this.flipY = true;
		}

		String mapOrientation = root.getAttribute("orientation", null);
		int mapWidth = root.getIntAttribute("width", 0);
		int mapHeight = root.getIntAttribute("height", 0);
		int tileWidth = root.getIntAttribute("tilewidth", 0);
		int tileHeight = root.getIntAttribute("tileheight", 0);
		int hexSideLength = root.getIntAttribute("hexsidelength", 0);
		String staggerAxis = root.getAttribute("staggeraxis", null);
		String staggerIndex = root.getAttribute("staggerindex", null);
		String mapBackgroundColor = root.getAttribute("backgroundcolor", null);

		MapProperties mapProperties = map.getProperties();
		if (mapOrientation != null) {
			mapProperties.put("orientation", mapOrientation);
		}
		mapProperties.put("width", mapWidth);
		mapProperties.put("height", mapHeight);
		mapProperties.put("tilewidth", tileWidth);
		mapProperties.put("tileheight", tileHeight);
		mapProperties.put("hexsidelength", hexSideLength);
		if (staggerAxis != null) {
			mapProperties.put("staggeraxis", staggerAxis);
		}
		if (staggerIndex != null) {
			mapProperties.put("staggerindex", staggerIndex);
		}
		if (mapBackgroundColor != null) {
			mapProperties.put("backgroundcolor", mapBackgroundColor);
		}
		this.mapTileWidth = tileWidth;
		this.mapTileHeight = tileHeight;
		this.mapWidthInPixels = mapWidth * tileWidth;
		this.mapHeightInPixels = mapHeight * tileHeight;

		if (mapOrientation != null) {
			if ("staggered".equals(mapOrientation)) {
				if (mapHeight > 1) {
					this.mapWidthInPixels += tileWidth / 2;
					this.mapHeightInPixels = mapHeightInPixels / 2 + tileHeight / 2;
				}
			}
		}

		Element properties = root.getChildByName("properties");
		if (properties != null) {
			loadProperties(map.getProperties(), properties);
		}

		Array<Element> tilesets = root.getChildrenByName("tileset");
		for (Element element : tilesets) {
			TiledMapTileSet tileSet = loadTileSet(element, tmxFile, imageResolver);
			root.removeChild(element);
			if (tileSet != null) {
				map.getTileSets().addTileSet(tileSet);
			}
		}

		for (int i = 0, j = root.getChildCount(); i < j; i++) {
			Element element = root.getChild(i);
			loadLayer(map, map.getLayers(), element, tmxFile, imageResolver);
		}

		// update hierarchical parallax scrolling factors
		// in Tiled the final parallax scrolling factor of a layer is the multiplication of its factor with all its parents
		// 1) get top level groups
		final Array<MapGroupLayer> groups = map.getLayers().getByType(MapGroupLayer.class);
		while (groups.notEmpty()) {
			final MapGroupLayer group = groups.first();
			groups.removeIndex(0);

			for (MapLayer child : group.getLayers()) {
				child.setParallaxX(child.getParallaxX() * group.getParallaxX());
				child.setParallaxY(child.getParallaxY() * group.getParallaxY());
				if (child instanceof MapGroupLayer) {
					// 2) handle any child groups
					groups.add((MapGroupLayer)child);
				}
			}
		}

		for (Runnable runnable : runOnEndOfLoadTiled) {
			runnable.run();
		}
		runOnEndOfLoadTiled = null;

		return map;
	}

	protected void loadLayer (TiledMap map, MapLayers parentLayers, Element element, FileHandle tmxFile,
		ImageResolver imageResolver) {
		String name = element.getName();
		if (name.equals("group")) {
			loadLayerGroup(map, parentLayers, element, tmxFile, imageResolver);
		} else if (name.equals("layer")) {
			loadTileLayer(map, parentLayers, element);
		} else if (name.equals("objectgroup")) {
			loadObjectGroup(map, parentLayers, element, tmxFile);
		} else if (name.equals("imagelayer")) {
			loadImageLayer(map, parentLayers, element, tmxFile, imageResolver);
		}
	}

	protected void loadLayerGroup (TiledMap map, MapLayers parentLayers, Element element, FileHandle tmxFile,
		ImageResolver imageResolver) {
		if (element.getName().equals("group")) {
			MapGroupLayer groupLayer = new MapGroupLayer();
			loadBasicLayerInfo(groupLayer, element);

			Element properties = element.getChildByName("properties");
			if (properties != null) {
				loadProperties(groupLayer.getProperties(), properties);
			}

			for (int i = 0, j = element.getChildCount(); i < j; i++) {
				Element child = element.getChild(i);
				loadLayer(map, groupLayer.getLayers(), child, tmxFile, imageResolver);
			}

			for (MapLayer layer : groupLayer.getLayers()) {
				layer.setParent(groupLayer);
			}

			parentLayers.add(groupLayer);
		}
	}

	protected void loadTileLayer (TiledMap map, MapLayers parentLayers, Element element) {
		if (element.getName().equals("layer")) {
			int width = element.getIntAttribute("width", 0);
			int height = element.getIntAttribute("height", 0);
			int tileWidth = map.getProperties().get("tilewidth", Integer.class);
			int tileHeight = map.getProperties().get("tileheight", Integer.class);
			TiledMapTileLayer layer = new TiledMapTileLayer(width, height, tileWidth, tileHeight);

			loadBasicLayerInfo(layer, element);

			int[] ids = getTileIds(element, width, height);
			TiledMapTileSets tilesets = map.getTileSets();
			for (int y = 0; y < height; y++) {
				for (int x = 0; x < width; x++) {
					int id = ids[y * width + x];
					boolean flipHorizontally = ((id & FLAG_FLIP_HORIZONTALLY) != 0);
					boolean flipVertically = ((id & FLAG_FLIP_VERTICALLY) != 0);
					boolean flipDiagonally = ((id & FLAG_FLIP_DIAGONALLY) != 0);

					TiledMapTile tile = tilesets.getTile(id & ~MASK_CLEAR);
					if (tile != null) {
						Cell cell = createTileLayerCell(flipHorizontally, flipVertically, flipDiagonally);
						cell.setTile(tile);
						layer.setCell(x, flipY ? height - 1 - y : y, cell);
					}
				}
			}

			Element properties = element.getChildByName("properties");
			if (properties != null) {
				loadProperties(layer.getProperties(), properties);
			}
			parentLayers.add(layer);
		}
	}

	protected void loadObjectGroup (TiledMap map, MapLayers parentLayers, Element element, FileHandle tmxFile) {
		if (element.getName().equals("objectgroup")) {
			MapLayer layer = new MapLayer();
			loadBasicLayerInfo(layer, element);
			Element properties = element.getChildByName("properties");
			if (properties != null) {
				loadProperties(layer.getProperties(), properties);
			}

			for (Element objectElement : element.getChildrenByName("object")) {
				Element elementToLoad = objectElement;
				if (objectElement.hasAttribute("template")) {
					elementToLoad = resolveTemplateObject(objectElement, tmxFile);
				}
				loadObject(map, layer, elementToLoad);
			}
			parentLayers.add(layer);
		}
	}

	protected void loadImageLayer (TiledMap map, MapLayers parentLayers, Element element, FileHandle tmxFile,
		ImageResolver imageResolver) {
		if (element.getName().equals("imagelayer")) {
			float x = 0;
			float y = 0;
			if (element.hasAttribute("offsetx")) {
				x = Float.parseFloat(element.getAttribute("offsetx", "0"));
			} else {
				x = Float.parseFloat(element.getAttribute("x", "0"));
			}
			if (element.hasAttribute("offsety")) {
				y = Float.parseFloat(element.getAttribute("offsety", "0"));
			} else {
				y = Float.parseFloat(element.getAttribute("y", "0"));
			}
			if (flipY) y = mapHeightInPixels - y;

			boolean repeatX = element.getIntAttribute("repeatx", 0) == 1;
			boolean repeatY = element.getIntAttribute("repeaty", 0) == 1;

			TextureRegion texture = null;

			Element image = element.getChildByName("image");

			if (image != null) {
				String source = image.getAttribute("source");
				FileHandle handle = getRelativeFileHandle(tmxFile, source);
				texture = imageResolver.getImage(handle.path());
				y -= texture.getRegionHeight();
			}

			TiledMapImageLayer layer = new TiledMapImageLayer(texture, x, y, repeatX, repeatY);

			loadBasicLayerInfo(layer, element);

			Element properties = element.getChildByName("properties");
			if (properties != null) {
				loadProperties(layer.getProperties(), properties);
			}

			parentLayers.add(layer);
		}
	}

	protected void loadBasicLayerInfo (MapLayer layer, Element element) {
		String name = element.getAttribute("name", null);
		float opacity = Float.parseFloat(element.getAttribute("opacity", "1.0"));
		String tintColor = element.getAttribute("tintcolor", "#ffffffff");
		boolean visible = element.getIntAttribute("visible", 1) == 1;
		float offsetX = element.getFloatAttribute("offsetx", 0);
		float offsetY = element.getFloatAttribute("offsety", 0);
		float parallaxX = element.getFloatAttribute("parallaxx", 1f);
		float parallaxY = element.getFloatAttribute("parallaxy", 1f);

		layer.setName(name);
		layer.setOpacity(opacity);
		layer.setVisible(visible);
		layer.setOffsetX(offsetX);
		layer.setOffsetY(offsetY);
		layer.setParallaxX(parallaxX);
		layer.setParallaxY(parallaxY);

		// set layer tint color after converting from #AARRGGBB to #RRGGBBAA
		layer.setTintColor(Color.valueOf(tiledColorToLibGDXColor(tintColor)));
	}

	protected void loadObject (TiledMap map, MapLayer layer, Element element) {
		loadObject(map, layer.getObjects(), element, mapHeightInPixels);
	}

	protected void loadObject (TiledMap map, TiledMapTile tile, Element element) {
		loadObject(map, tile.getObjects(), element, tile.getTextureRegion().getRegionHeight());
	}

	protected void loadObject (TiledMap map, MapObjects objects, Element element, float heightInPixels) {
		if (element.getName().equals("object")) {
			MapObject object = null;

			float scaleX = convertObjectToTileSpace ? 1.0f / mapTileWidth : 1.0f;
			float scaleY = convertObjectToTileSpace ? 1.0f / mapTileHeight : 1.0f;

			float x = element.getFloatAttribute("x", 0) * scaleX;
			float y = (flipY ? (heightInPixels - element.getFloatAttribute("y", 0)) : element.getFloatAttribute("y", 0)) * scaleY;

			float width = element.getFloatAttribute("width", 0) * scaleX;
			float height = element.getFloatAttribute("height", 0) * scaleY;

			if (element.getChildCount() > 0) {
				Element child = null;
				if ((child = element.getChildByName("polygon")) != null) {
					String[] points = child.getAttribute("points").split(" ");
					float[] vertices = new float[points.length * 2];
					for (int i = 0; i < points.length; i++) {
						String[] point = points[i].split(",");
						vertices[i * 2] = Float.parseFloat(point[0]) * scaleX;
						vertices[i * 2 + 1] = Float.parseFloat(point[1]) * scaleY * (flipY ? -1 : 1);
					}
					Polygon polygon = new Polygon(vertices);
					polygon.setPosition(x, y);
					object = new PolygonMapObject(polygon);
				} else if ((child = element.getChildByName("polyline")) != null) {
					String[] points = child.getAttribute("points").split(" ");
					float[] vertices = new float[points.length * 2];
					for (int i = 0; i < points.length; i++) {
						String[] point = points[i].split(",");
						vertices[i * 2] = Float.parseFloat(point[0]) * scaleX;
						vertices[i * 2 + 1] = Float.parseFloat(point[1]) * scaleY * (flipY ? -1 : 1);
					}
					Polyline polyline = new Polyline(vertices);
					polyline.setPosition(x, y);
					object = new PolylineMapObject(polyline);
				} else if ((child = element.getChildByName("ellipse")) != null) {
					object = new EllipseMapObject(x, flipY ? y - height : y, width, height);
				} else if ((child = element.getChildByName("point")) != null) {
					object = new PointMapObject(x, flipY ? y - height : y);
				} else if ((child = element.getChildByName("text")) != null) {
					TextMapObject textMapObject = new TextMapObject(x, flipY ? y - height : y, width, height, child.getText());
					textMapObject.setFontFamily(child.getAttribute("fontfamily", ""));
					textMapObject.setPixelSize(child.getIntAttribute("pixelSize", 16));
					textMapObject.setHorizontalAlign(child.getAttribute("halign", "left"));
					textMapObject.setVerticalAlign(child.getAttribute("valign", "top"));
					textMapObject.setBold(child.getIntAttribute("bold", 0) == 1);
					textMapObject.setItalic(child.getIntAttribute("italic", 0) == 1);
					textMapObject.setUnderline(child.getIntAttribute("underline", 0) == 1);
					textMapObject.setStrikeout(child.getIntAttribute("strikeout", 0) == 1);
					textMapObject.setWrap(child.getIntAttribute("wrap", 0) == 1);
					// When kerning is true, it won't be added as an attribute, it's true by default
					textMapObject.setKerning(child.getIntAttribute("kerning", 1) == 1);
					// Default color is #000000, not added as attribute
					String textColor = child.getAttribute("color", "#000000");
					textMapObject.setColor(Color.valueOf(tiledColorToLibGDXColor(textColor)));
					object = textMapObject;
				}
			}
			if (object == null) {
				String gid = null;
				if ((gid = element.getAttribute("gid", null)) != null) {
					int id = (int)Long.parseLong(gid);
					boolean flipHorizontally = ((id & FLAG_FLIP_HORIZONTALLY) != 0);
					boolean flipVertically = ((id & FLAG_FLIP_VERTICALLY) != 0);

					TiledMapTile tile = map.getTileSets().getTile(id & ~MASK_CLEAR);
					TiledMapTileMapObject tiledMapTileMapObject = new TiledMapTileMapObject(tile, flipHorizontally, flipVertically);
					TextureRegion textureRegion = tiledMapTileMapObject.getTextureRegion();
					tiledMapTileMapObject.getProperties().put("gid", id);
					tiledMapTileMapObject.setX(x);
					tiledMapTileMapObject.setY(flipY ? y : y - height);
					float objectWidth = element.getFloatAttribute("width", textureRegion.getRegionWidth());
					float objectHeight = element.getFloatAttribute("height", textureRegion.getRegionHeight());
					tiledMapTileMapObject.setScaleX(scaleX * (objectWidth / textureRegion.getRegionWidth()));
					tiledMapTileMapObject.setScaleY(scaleY * (objectHeight / textureRegion.getRegionHeight()));
					tiledMapTileMapObject.setRotation(element.getFloatAttribute("rotation", 0));
					object = tiledMapTileMapObject;
				} else {
					object = new RectangleMapObject(x, flipY ? y - height : y, width, height);
				}
			}
			object.setName(element.getAttribute("name", null));
			String rotation = element.getAttribute("rotation", null);
			if (rotation != null) {
				object.getProperties().put("rotation", Float.valueOf(rotation));
			}
			String type = element.getAttribute("type", null);
			if (type != null) {
				object.getProperties().put("type", type);
			}
			int id = element.getIntAttribute("id", 0);
			if (id != 0) {
				object.getProperties().put("id", id);
			}
			object.getProperties().put("x", x);

			if (object instanceof TiledMapTileMapObject) {
				object.getProperties().put("y", y);
			} else {
				object.getProperties().put("y", (flipY ? y - height : y));
			}
			object.getProperties().put("width", width);
			object.getProperties().put("height", height);
			object.setVisible(element.getIntAttribute("visible", 1) == 1);
			Element properties = element.getChildByName("properties");
			if (properties != null) {
				loadProperties(object.getProperties(), properties);
			}

			// if there is a 'type' (=class) specified, then check if there are any other
			// class properties available and put their default values into the properties.
			loadMapPropertiesClassDefaults(type, object.getProperties());

			idToObject.put(id, object);
			objects.add(object);
		}
	}

	/** Method specifically meant to help resolve template object properties and attributes found in objectgroups. Each template
	 * object links to a specific .tx file. Attributes and properties found in the template are allowed to be overwritten by any
	 * matching ones found in its parent element. Knowing this, we will merge the two elements together with the parent's props
	 * taking precedence and then return the merged value.
	 * @param mapElement Element which contains the single xml element we are currently parsing
	 * @param tmxFile tmxFile
	 * @return a merged Element representing the combined elements. */
	protected Element resolveTemplateObject (Element mapElement, FileHandle tmxFile) {
		// Get template (.tx) file name from element
		String txFileName = mapElement.getAttribute("template");

		// Template's own tileset declaration. We will need this to figure out how the template's
		// local gids map to the map's global gids.
		FileHandle templateFile = getRelativeFileHandle(tmxFile, txFileName);

		// check for cached tx element
		Element templateElement = templateCache.get(txFileName);
		if (templateElement == null) {
			// parse the .tx template file
			try {
				templateElement = xml.parse(templateFile);
			} catch (Exception e) {
				throw new GdxRuntimeException("Error parsing template file: " + txFileName, e);
			}
			templateCache.put(txFileName, templateElement);
		}
		// Get the root object from the template file
		Element templateObjectElement = templateElement.getChildByName("object");

		// Calculate the GID shift or keep as 0 if not required
		int addGID = 0;
		// Get the template tileset source path if any
		Element templateTilesetSource = templateElement.getChildByName("tileset");
		if (templateTilesetSource != null) {
			// Resolve the tileset path relative to the TEMPLATE file, because the
			// "source" in the template is stored relative to the template's location.
			String tilesetPath = getRelativeFileHandle(templateFile, templateTilesetSource.getAttribute("source")).path();
			addGID = tilesetPathsToGIDs.get(tilesetPath, 0) - 1;
		}
		// Inject the GID into the object instance in the map
		if (templateObjectElement.hasAttribute("gid")) {
			if (!mapElement.hasAttribute("gid")) {
				mapElement.setAttribute("gid", Integer.toString(templateObjectElement.getIntAttribute("gid") + addGID));
			}
		}

		// Merge the parent map element with its template element
		return mergeParentElementWithTemplate(mapElement, templateObjectElement);
	}

	/** Returns a shallow copy of the source element we pass in. */
	protected Element cloneElementShallow (Element sourceElement) {
		// New element for our copy
		Element copyElement = new Element(sourceElement.getName(), null);
		// Get list of attributes from the source element
		ObjectMap<String, String> attrs = sourceElement.getAttributes();
		if (attrs != null) {
			// Place those entries in our new copied element
			for (ObjectMap.Entry<String, String> entry : attrs.entries()) {
				copyElement.setAttribute(entry.key, entry.value);
			}
		}
		// Checking for text
		if (sourceElement.getText() != null) copyElement.setText(sourceElement.getText());
		return copyElement;
	}

	/** Merges two <properties> tags from a parent and template. Matching properties from the parent will override the
	 * template's. */
	protected Element mergeProperties (Element parentProps, Element templateProps) {
		if (templateProps == null) return parentProps;
		if (parentProps == null) return templateProps;
		// Create a new merged properties element which will contain a combination of parent and template properties.
		Element merged = new Element("properties", null);
		// Set properties from template
		for (Element property : templateProps.getChildrenByName("property")) {
			merged.addChild(cloneElementShallow(property));
		}
		// Set properties from the parent, matching ones from template will be overridden
		for (Element property : parentProps.getChildrenByName("property")) {
			String name = property.getAttribute("name", null);
			// Find & remove a duplicate by name, if any
			// Remove existing with same name (if any)
			Element existing = null;
			for (int i = 0; i < merged.getChildCount(); i++) {
				Element child = merged.getChild(i);
				if ("property".equals(child.getName()) && name.equals(child.getAttribute("name", null))) {
					existing = child;
					break;
				}
			}
			if (existing != null) merged.removeChild(existing);
			merged.addChild(cloneElementShallow(property));
		}
		return merged;
	}

	/** Recursively merges a “parent” (map) object element with its referenced template object element. Attributes and properties
	 * found in the template are allowed to be overwritten by any matching ones found in its parent element. The returned element
	 * is a new detached tree (parent = null) so it can be handed straight to the loadObject() method without issues. */
	protected Element mergeParentElementWithTemplate (Element parent, Element template) {
		if (template == null) return parent;
		if (parent == null) return template;
		// Create a new merged element which will contain a combination of parent and template attributes, properties etc...
		Element merged = new Element(template.getName(), null);
		// Set attributes from template
		if (template.getAttributes() != null) {
			for (ObjectMap.Entry<String, String> a : template.getAttributes().entries()) {
				merged.setAttribute(a.key, a.value);
			}
		}
		// Set attributes from the parent, matching ones from template will be overridden
		if (parent.getAttributes() != null) {
			for (ObjectMap.Entry<String, String> a : parent.getAttributes().entries()) {
				merged.setAttribute(a.key, a.value);
			}
		}
		// Specifically added for TextMapObjects since they are unique compared to other objects.
		String txt = (parent.getText() != null && parent.getText().length() > 0) ? parent.getText() : template.getText();
		if (txt != null) {
			merged.setText(txt);
		}
		// Handle Child Elements
		// Collect all child tag names that appear in either element
		ObjectSet<String> tagNames = new ObjectSet<>();
		for (int i = 0; i < template.getChildCount(); i++)
			tagNames.add(template.getChild(i).getName());
		for (int i = 0; i < parent.getChildCount(); i++)
			tagNames.add(parent.getChild(i).getName());

		for (String tag : tagNames) {
			Element mapChild = parent.getChildByName(tag);
			Element tmplChild = template.getChildByName(tag);

			/** Look for properties tags so we can merge those as well. Recursive check if properties is not found. */
			Element mergedChild = "properties".equals(tag) ? mergeProperties(mapChild, tmplChild)
				: mergeParentElementWithTemplate(mapChild, tmplChild);
			merged.addChild(mergedChild);
		}
		return merged;
	}
	/* * End of Tiled Template Loading Section * */

	protected void loadProperties (final MapProperties properties, Element element) {
		if (element == null) return;
		if (element.getName().equals("properties")) {
			for (Element property : element.getChildrenByName("property")) {
				final String name = property.getAttribute("name", null);
				String value = getPropertyValue(property);
				String type = property.getAttribute("type", null);
				if ("object".equals(type)) {
					loadObjectProperty(properties, name, value);
				} else if ("class".equals(type)) {
					// A 'class' property is a property which is itself a set of properties
					MapProperties classProperties = new MapProperties();
					String className = property.getAttribute("propertytype");
					classProperties.put("type", className);
					// the actual properties of a 'class' property are stored as a new properties tag
					properties.put(name, classProperties);
					loadClassProperties(className, classProperties, property.getChildByName("properties"));
				} else {
					loadBasicProperty(properties, name, value, type);
				}
			}
		}
	}

	protected void loadClassProperties (String className, MapProperties classProperties, XmlReader.Element classElement) {
		if (projectClassInfo == null) {
			throw new GdxRuntimeException(
				"No class information loaded to support class properties. Did you set the 'projectFilePath' parameter?");
		}
		if (projectClassInfo.isEmpty()) {
			throw new GdxRuntimeException(
				"No class information available. Did you set the correct Tiled project path in the 'projectFilePath' parameter?");
		}
		Array<ProjectClassMember> projectClassMembers = projectClassInfo.get(className);
		if (projectClassMembers == null) {
			throw new GdxRuntimeException("There is no class with name '" + className + "' in given Tiled project file.");
		}

		for (ProjectClassMember projectClassMember : projectClassMembers) {
			String propName = projectClassMember.name;
			XmlReader.Element classProp = classElement == null ? null : getPropertyByName(classElement, propName);
			switch (projectClassMember.type) {
			case "object": {
				String value = classProp == null ? projectClassMember.defaultValue.asString() : getPropertyValue(classProp);
				loadObjectProperty(classProperties, propName, value);
				break;
			}
			case "class": {
				// A 'class' property is a property which is itself a set of properties
				MapProperties nestedClassProperties = new MapProperties();
				String nestedClassName = projectClassMember.propertyType;
				nestedClassProperties.put("type", nestedClassName);
				// the actual properties of a 'class' property are stored as a new properties tag
				classProperties.put(propName, nestedClassProperties);
				if (classProp == null) {
					// no class values overridden -> use default class values
					loadJsonClassProperties(nestedClassName, nestedClassProperties, projectClassMember.defaultValue);
				} else {
					loadClassProperties(nestedClassName, nestedClassProperties, classProp);
				}
				break;
			}
			default: {
				String value = classProp == null ? projectClassMember.defaultValue.asString() : getPropertyValue(classProp);
				loadBasicProperty(classProperties, propName, value, projectClassMember.type);
				break;
			}
			}
		}
	}

	private static String getPropertyValue (Element classProp) {
		return classProp.getAttribute("value", classProp.getText());
	}

	protected Element getPropertyByName (Element classElement, String propName) {
		// we use getChildrenByNameRecursively here because in case of nested classes,
		// we get an element with a root property (=class) and inside additional property tags for the real
		// class properties. If we just use getChildrenByName we don't get any children for a nested class.
		for (Element property : classElement.getChildrenByNameRecursively("property")) {
			if (propName.equals(property.getAttribute("name"))) {
				return property;
			}
		}
		return null;
	}

	static public int[] getTileIds (Element element, int width, int height) {
		Element data = element.getChildByName("data");
		String encoding = data.getAttribute("encoding", null);
		if (encoding == null) { // no 'encoding' attribute means that the encoding is XML
			throw new GdxRuntimeException("Unsupported encoding (XML) for TMX Layer Data");
		}
		int[] ids = new int[width * height];
		if (encoding.equals("csv")) {
			String[] array = data.getText().split(",");
			for (int i = 0; i < array.length; i++)
				ids[i] = (int)Long.parseLong(array[i].trim());
		} else {
			if (true) if (encoding.equals("base64")) {
				InputStream is = null;
				try {
					String compression = data.getAttribute("compression", null);
					byte[] bytes = Base64Coder.decode(data.getText());
					if (compression == null)
						is = new ByteArrayInputStream(bytes);
					else if (compression.equals("gzip"))
						is = new BufferedInputStream(new GZIPInputStream(new ByteArrayInputStream(bytes), bytes.length));
					else if (compression.equals("zlib"))
						is = new BufferedInputStream(new InflaterInputStream(new ByteArrayInputStream(bytes)));
					else
						throw new GdxRuntimeException("Unrecognised compression (" + compression + ") for TMX Layer Data");

					byte[] temp = new byte[4];
					for (int y = 0; y < height; y++) {
						for (int x = 0; x < width; x++) {
							int read = is.read(temp);
							while (read < temp.length) {
								int curr = is.read(temp, read, temp.length - read);
								if (curr == -1) break;
								read += curr;
							}
							if (read != temp.length)
								throw new GdxRuntimeException("Error Reading TMX Layer Data: Premature end of tile data");
							ids[y * width + x] = unsignedByteToInt(temp[0]) | unsignedByteToInt(temp[1]) << 8
								| unsignedByteToInt(temp[2]) << 16 | unsignedByteToInt(temp[3]) << 24;
						}
					}
				} catch (IOException e) {
					throw new GdxRuntimeException("Error Reading TMX Layer Data - IOException: " + e.getMessage());
				} finally {
					StreamUtils.closeQuietly(is);
				}
			} else {
				// any other value of 'encoding' is one we're not aware of, probably a feature of a future version of Tiled
				// or another editor
				throw new GdxRuntimeException("Unrecognised encoding (" + encoding + ") for TMX Layer Data");
			}
		}
		return ids;
	}

	public TiledMapTileSet loadTileSet (Element tilesetElementRaw, FileHandle tmxFile, ImageResolver imageResolver) {
		int firstgid = tilesetElementRaw.getIntAttribute("firstgid", 1);
		Element tilesetElement = resolveTilesetElement(tilesetElementRaw, tmxFile);

		String name = tilesetElement.get("name", null);
		int tilewidth = tilesetElement.getIntAttribute("tilewidth", 0);
		int tileheight = tilesetElement.getIntAttribute("tileheight", 0);
		int spacing = tilesetElement.getIntAttribute("spacing", 0);
		int margin = tilesetElement.getIntAttribute("margin", 0);

		int offsetX = 0, offsetY = 0;
		Element offset = tilesetElement.getChildByName("tileoffset");
		if (offset != null) {
			offsetX = offset.getIntAttribute("x", 0);
			offsetY = offset.getIntAttribute("y", 0);
		}

		FileHandle image = resolveTilesetImage(tilesetElement, tmxFile);
		Element imageElement = tilesetElement.getChildByName("image");
		String imageSource = (imageElement != null) ? imageElement.getAttribute("source", null) : null;
		int imageWidth = (imageElement != null) ? imageElement.getIntAttribute("width", 0) : 0;
		int imageHeight = (imageElement != null) ? imageElement.getIntAttribute("height", 0) : 0;

		TiledMapTileSet tileSet = new TiledMapTileSet();
		tileSet.setName(name);
		tileSet.getProperties().put("firstgid", firstgid);

		Element properties = tilesetElement.getChildByName("properties");
		if (properties != null) {
			loadProperties(tileSet.getProperties(), properties);
		}

		Array<Element> tileElements = tilesetElement.getChildrenByName("tile");

		addStaticTiles(tmxFile, imageResolver, tileSet, tilesetElement, tileElements, name, firstgid, tilewidth, tileheight,
			spacing, margin, offsetX, offsetY, imageSource, imageWidth, imageHeight, image);

		Array<AnimatedTiledMapTile> animatedTiles = new Array<>();
		for (Element tileElement : tileElements) {
			int localtid = tileElement.getIntAttribute("id", 0);
			TiledMapTile tile = tileSet.getTile(firstgid + localtid);
			if (tile != null) {
				AnimatedTiledMapTile animatedTile = createAnimatedTile(tileSet, tile, tileElement, firstgid);
				if (animatedTile != null) {
					animatedTiles.add(animatedTile);
					tile = animatedTile;
				}
				addTileProperties(tile, tileElement);
				addTileObjectGroup(tile, tileElement);
			}
		}
		for (AnimatedTiledMapTile animatedTile : animatedTiles) {
			tileSet.putTile(animatedTile.getId(), animatedTile);
		}

		return tileSet;
	}

	private Element resolveTilesetElement (Element tilesetElement, FileHandle tmxFile) {
		String source = tilesetElement.getAttribute("source", null);
		if (source != null) {
			FileHandle tsx = getRelativeFileHandle(tmxFile, source);
			if (tilesetPathsToGIDs != null) {
				int firstgid = tilesetElement.getIntAttribute("firstgid", 1);
				tilesetPathsToGIDs.put(tsx.path(), firstgid);
			}
			try {
				Element tsxElement = xml.parse(tsx);
				tsxElement.setAttribute("source", source);
				return tsxElement;
			} catch (SerializationException e) {
				throw new GdxRuntimeException("Error parsing external tileset: " + source, e);
			}
		}
		return tilesetElement;
	}

	private FileHandle resolveTilesetImage (Element tilesetElement, FileHandle tmxFile) {
		Element imageElement = tilesetElement.getChildByName("image");
		if (imageElement == null) return null;

		String imageSource = imageElement.getAttribute("source");
		String tilesetSource = tilesetElement.getAttribute("source", null);

		FileHandle base = (tilesetSource != null) ? getRelativeFileHandle(tmxFile, tilesetSource) : tmxFile;

		return getRelativeFileHandle(base, imageSource);
	}

	protected abstract void addStaticTiles (FileHandle tmxFile, ImageResolver imageResolver, TiledMapTileSet tileset,
		Element element, Array<Element> tileElements, String name, int firstgid, int tilewidth, int tileheight, int spacing,
		int margin, int offsetX, int offsetY, String imageSource, int imageWidth, int imageHeight, FileHandle image);

	protected void addTileProperties (TiledMapTile tile, Element tileElement) {
		String terrain = tileElement.getAttribute("terrain", null);
		MapProperties tileProperties = tile.getProperties();
		if (terrain != null) {
			tileProperties.put("terrain", terrain);
		}
		String probability = tileElement.getAttribute("probability", null);
		if (probability != null) {
			tileProperties.put("probability", probability);
		}
		String type = tileElement.getAttribute("type", null);
		if (type != null) {
			tileProperties.put("type", type);
		}
		Element properties = tileElement.getChildByName("properties");
		if (properties != null) {
			loadProperties(tileProperties, properties);
		}

		// if there is a 'type' (=class) specified, then check if there are any other
		// class properties available and put their default values into the properties.
		loadMapPropertiesClassDefaults(type, tileProperties);
	}

	protected void addTileObjectGroup (TiledMapTile tile, Element tileElement) {
		Element objectgroupElement = tileElement.getChildByName("objectgroup");
		if (objectgroupElement != null) {
			for (Element objectElement : objectgroupElement.getChildrenByName("object")) {
				loadObject(map, tile, objectElement);
			}
		}
	}

	protected AnimatedTiledMapTile createAnimatedTile (TiledMapTileSet tileSet, TiledMapTile tile, Element tileElement,
		int firstgid) {
		Element animationElement = tileElement.getChildByName("animation");
		if (animationElement != null) {
			Array<StaticTiledMapTile> staticTiles = new Array<>();
			IntArray intervals = new IntArray();
			for (Element frameElement : animationElement.getChildrenByName("frame")) {
				staticTiles.add((StaticTiledMapTile)tileSet.getTile(firstgid + frameElement.getIntAttribute("tileid")));
				intervals.add(frameElement.getIntAttribute("duration"));
			}

			AnimatedTiledMapTile animatedTile = new AnimatedTiledMapTile(intervals, staticTiles);
			animatedTile.setId(tile.getId());
			return animatedTile;
		}
		return null;
	}

}
